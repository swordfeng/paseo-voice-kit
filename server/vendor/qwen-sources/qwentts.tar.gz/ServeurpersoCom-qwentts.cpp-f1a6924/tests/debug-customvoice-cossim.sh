#!/bin/bash

for backend in CUDA0 Vulkan0 CPU; do
    for quant in F32 BF16 Q8_0 Q4_K_M; do
        ./debug-customvoice-cossim.py --device $backend --quant $quant \
            2>&1 | tee customvoice-${backend}-${quant}.log
    done
done
